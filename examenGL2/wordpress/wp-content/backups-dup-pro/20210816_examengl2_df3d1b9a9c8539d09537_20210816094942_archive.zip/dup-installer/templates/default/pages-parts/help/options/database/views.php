<?php
defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">Views</td>
    <td>
        Enable creation of views. Checked by default.
    </td>
</tr>