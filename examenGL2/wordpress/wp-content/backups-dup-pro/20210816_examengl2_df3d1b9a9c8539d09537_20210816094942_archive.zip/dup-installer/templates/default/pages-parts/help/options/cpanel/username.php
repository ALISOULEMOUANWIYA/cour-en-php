<?php
defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">Username</td>
    <td>
        The cPanel username used to login to your cPanel account.  <i>This is <b>not</b> the same thing as your WordPress administrator account</i>.
        If you're unsure of this name please contact your hosting provider or server administrator.
    </td>
</tr>