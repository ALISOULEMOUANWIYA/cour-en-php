<?php
defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">Email</td>
    <td>The Email of the new user. A mandatory field when creating a new user.</td>
</tr>