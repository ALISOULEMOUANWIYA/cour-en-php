<?php
defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<div id="installer-mode-content">
    The installer has two operating modes: 
    <ol>
        <li>
            a two step Basic mode.
        </li>
        <li>
            a four step Advanced mode.
        </li>
    </ol>    
    This help is geared toward the four step Advanced mode but the information help still applies to the two step Basic since Basic mode is a subset of Advanced mode.
</div>