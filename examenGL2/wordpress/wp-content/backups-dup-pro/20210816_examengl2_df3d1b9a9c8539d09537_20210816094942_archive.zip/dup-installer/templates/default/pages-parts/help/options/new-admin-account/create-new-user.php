<?php
defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">Create New User</td>
    <td>Create a new user account.</td>
</tr>