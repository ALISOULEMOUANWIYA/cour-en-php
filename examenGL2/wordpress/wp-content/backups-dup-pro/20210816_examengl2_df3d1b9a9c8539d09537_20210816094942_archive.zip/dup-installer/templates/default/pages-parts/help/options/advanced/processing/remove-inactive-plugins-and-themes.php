<?php
defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">Remove Inactive Plugins <br/>and Themes</td>
    <td>
        Remove all inactive plugins and themes when installing site.  Inactive users will also be removed during subsite to standalone migrations.
    </td>
</tr>