<?php
defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">File Times</td>
    <td>
        When the archive is extracted should it show the current date-time or keep the original time it had when it was built.  This setting will be applied to all files and directories.
    </td>
</tr>