 <?php
session_start(); 
    require_once 'config.php';

  class ControllersUser{
    private $Utilisateur = ""; 
    private $tableau; 
    private $tableau2; 
    private $ListesSerache; 
    public function __construct(){
        $this->database = new Database();
    }
    public function Listes(){
        $requetes = "Select * from users WHERE NOT unique_id = ?";
        $query = $this->database->getDBB()->prepare($requetes);
        $query->execute(array($_SESSION['ID_unique']));
        $this->setListes($query->fetchAll());
    }
    public function get_courtMessage($Courte){
        $requete = "SELECT * FROM messages
        WHERE (incoming_msg_id = ? OR outgoing_msg_id = ?) ORDER BY msg_id DESC LIMIT 1";
        $queryprepare = $this->database->getDBB()->prepare($requete);
          // Exécuter la requête 
        $queryprepare->execute(array($Courte, $Courte));
        $this->setMessage($queryprepare->fetch());
    }
    public function Comptes(){
        $resultatNombre_ID = 0;
        $i=0;
        $this->listes();
        if(sizeof($this->getListes()) > 0){
            
          foreach($this->getListes() as $row ){
              $this->get_courtMessage($row['unique_id']);
              if(is_array($this->getMessage())){
                if(sizeof($this->getMessage()) > 0 ){
                  $resultat = $this->getMessage()['msg']; 
                  $resultatNombre_ID = $this->getMessage()['outgoing_msg_id']; 
                }else{
                  $resultat = "Aucun message disponible";
                }
              }else{
                  $resultat = "Aucun message disponible";
              }
              // Obtenire un message courte
                (strlen($resultat) > 28) ? $msg = substr($resultat, 0, 28).'...' : $msg = $resultat;
              // ajouter distributeur
                ($_SESSION['ID_unique'] == $resultatNombre_ID) ? $you = "Vous : " : $you = " ";
              //Verification connexion instentaner 
                ($row['status'] == "hors ligne maintenant") ? $offline = "offline" : $offline = "";
//            if($_SESSION['ID_unique'] != $row['unique_id']){
                $this->Utilisateur .= '<a href="index.php?view=chat&user_id='.$row['unique_id'].'">
                <div class="content">
                  <img src="#" alt="">
                  <div class="details">
                     <span>'.$row['fname']." ".$row['lname'].'</span>
                   <p>'.$you." ".$msg.'</p>
                 </div>
                 </div>
                 <div class="status-dot '.$offline.'">
                  <i class="fa fa-circle" aria-hidden="true"></i>
                 </div>
               </a>';   
//            }
           }
        }
        echo $this->Utilisateur;
    }
    
      //Les GETTER
    public function getListes(){
      return($this->tableau);   
    }
    public function getMessage(){
      return($this->tableau2);   
    }

      //Les SETTER
    public function setListes($valeur){
      $this->tableau = $valeur;   
    }
    public function setMessage($valeur){
      $this->tableau2 = $valeur;   
    }

  }
 $compteUser = new ControllersUser();
  $compteUser->comptes();
?>