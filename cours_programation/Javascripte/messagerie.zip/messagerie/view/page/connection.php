
<div class="wrapper">
           <section class="form login">
             <header>Application de chat en temps réel</header>
             <form action="#" autocomplete="off">
               <div class="error-txt">c'est un error message!</div>
                 <div class="field input">
                    <label>Email Address</label>
                    <input type="email" name="email" placeholder="Entrez Votre Eamil" required>
                  </div>
                  <div class="field input">
                    <label>Mot de Passe</label>
                    <input type="current-password" name="password" placeholder="Entrez Password" required>
                    <i class="fa fa-eye" aria-hidden="true"></i>
                  </div>
                  <div class="field button">
                    <input type="submit" value="Enrigistrer">
                  </div>
             </form>
             <div class="link">
                Pas inscrit ? <a href="index.php?view=add">Creer maintenant</a>
             </div>
           </section>
       </div>
<script src="assets/javascripte/login.js"></script>
<script src="assets/javascripte/pass_show_hide.js"></script>