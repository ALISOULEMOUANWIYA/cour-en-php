<?php
  session_start();
if(!isset($_SESSION['unique'])){
    header("location: http://localhost/JAVASCRIPTE/messagerie/index.php");
}else{
    $_SESSION['ID_unique'] = $_SESSION['unique'];
    require_once "controllers/scripte_controller_php/Chat_Id.php";
    $compteUser = new Chat_Id();
    $compteUser->Personne($_SESSION['ID_unique']);
}
?>
<div class="wrapper">
  <section class="user">
    <header>
        <div class="content">
            <img src="#" alt="">
            <div class="details">
               <span><?php echo $compteUser->getListes()['fname']." ".$compteUser->getListes()['lname'];?></span>
               <p><?php echo $compteUser->getListes()['status'];?></p>
            </div>
        </div>
        <a href="index.php?view=dec&partire=<?php echo $_SESSION['unique'];?>" class="logout">Logout</a>    
    </header>
    <div class="search">
        <span>Select un user to start chat</span>
        <input type="text" placeholder="Entrer le nom de recherche">
        <button><i class="fa fa-search" aria-hidden="true"></i></button>
    </div>
    <div class="user-list">

    </div>
  </section>
</div>
<script src="assets/javascripte/user.js"></script>