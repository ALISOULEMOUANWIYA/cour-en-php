<!DOCTYPE html>
  <html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
    <title> MESSAGERIE </title>
    <link rel="stylesheet" href="assets/fontawesome/css/font-awesome.css">
    <link rel="stylesheet" href="assets/dossierStyle/style0.css">
    <link rel="stylesheet" href="assets/dossierStyle/style.css">
    <link rel="stylesheet" href="assets/dossierStyle/style3.css">
    <link rel="stylesheet" href="assets/dossierStyle/fichier.css">
  </head>
<body>
    